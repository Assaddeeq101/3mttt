# Nigeria Bills App - Technical Documentation

## Architecture Overview

### Tech Stack
- **Backend**: Node.js, Express.js, MongoDB
- **Frontend**: Vanilla JavaScript, Responsive CSS
- **Database**: MongoDB with Mongoose ODM
- **Authentication**: JWT (JSON Web Tokens)
- **Payment**: Flutterwave, Paystack integration
- **Deployment**: Docker, PM2, Nginx

### Project Structure
```
nigeria-bills-app/
├── server.js                 # Main server file
├── package.json             # Dependencies and scripts
├── .env.example            # Environment variables template
├── models/                 # Database models
│   ├── User.js            # User model
│   ├── Transaction.js     # Transaction model
│   ├── DataPlan.js        # Data plans model
│   └── Wallet.js          # Wallet model
├── routes/                 # API routes
│   ├── auth.js            # Authentication routes
│   ├── airtime.js         # Airtime purchase routes
│   ├── data.js            # Data bundle routes
│   ├── bills.js           # Bill payment routes
│   ├── wallet.js          # Wallet management routes
│   ├── transactions.js    # Transaction history
│   └── users.js           # User management routes
├── middleware/             # Express middleware
│   └── auth.js            # Authentication middleware
├── public/                # Static files
│   ├── css/               # Stylesheets
│   ├── js/                # JavaScript files
│   └── images/            # Images and icons
├── docs/                  # Documentation
│   ├── BUSINESS_SETUP.md  # Business setup guide
│   └── TECHNICAL_DOCUMENTATION.md
└── README.md              # Project documentation
```

## API Documentation

### Authentication Endpoints

#### Register User
```http
POST /api/auth/register
Content-Type: application/json

{
  "fullName": "John Doe",
  "email": "john@example.com",
  "phoneNumber": "08012345678",
  "password": "securepassword123",
  "referredBy": "ABC123"  // optional
}
```

#### Login User
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "securepassword123"
}
```

#### Get User Profile
```http
GET /api/auth/profile
Authorization: Bearer <token>
```

### Airtime Endpoints

#### Get Airtime Prices
```http
GET /api/airtime/prices
```

#### Buy Airtime
```http
POST /api/airtime/buy
Authorization: Bearer <token>
Content-Type: application/json

{
  "network": "mtn",
  "amount": 1000,
  "phoneNumber": "08012345678",
  "paymentMethod": "wallet"
}
```

#### Get Airtime History
```http
GET /api/airtime/history?page=1&limit=10
Authorization: Bearer <token>
```

### Data Endpoints

#### Get Data Plans
```http
GET /api/data/plans/mtn
```

#### Buy Data Bundle
```http
POST /api/data/buy
Authorization: Bearer <token>
Content-Type: application/json

{
  "planId": "507f1f77bcf86cd799439011",
  "phoneNumber": "08012345678",
  "paymentMethod": "wallet"
}
```

### Bill Payment Endpoints

#### Get Bill Categories
```http
GET /api/bills/categories
```

#### Get Bill Packages
```http
GET /api/bills/packages/dstv
```

#### Verify Bill Details
```http
POST /api/bills/verify
Authorization: Bearer <token>
Content-Type: application/json

{
  "provider": "dstv",
  "customerId": "1234567890"
}
```

#### Pay Bill
```http
POST /api/bills/pay
Authorization: Bearer <token>
Content-Type: application/json

{
  "provider": "dstv",
  "customerId": "1234567890",
  "amount": 21000,
  "paymentMethod": "wallet"
}
```

### Wallet Endpoints

#### Get Wallet Balance
```http
GET /api/wallet/balance
Authorization: Bearer <token>
```

#### Fund Wallet
```http
POST /api/wallet/fund
Authorization: Bearer <token>
Content-Type: application/json

{
  "amount": 5000,
  "paymentMethod": "card",
  "paymentGateway": "flutterwave"
}
```

#### Withdraw from Wallet
```http
POST /api/wallet/withdraw
Authorization: Bearer <token>
Content-Type: application/json

{
  "amount": 2000,
  "bankAccount": {
    "bankName": "GTBank",
    "accountNumber": "0123456789",
    "accountName": "John Doe"
  },
  "narration": "Withdrawal to bank account"
}
```

### Transaction Endpoints

#### Get All Transactions
```http
GET /api/transactions?page=1&limit=10&type=airtime&status=completed
Authorization: Bearer <token>
```

#### Get Transaction by ID
```http
GET /api/transactions/:id
Authorization: Bearer <token>
```

#### Generate Receipt
```http
GET /api/transactions/:id/receipt
Authorization: Bearer <token>
```

## Database Schema

### User Schema
```javascript
{
  _id: ObjectId,
  fullName: String,
  email: String,
  phoneNumber: String,
  password: String,
  bvn: String,
  nin: String,
  isVerified: Boolean,
  verificationLevel: Number,
  walletBalance: Number,
  commissionBalance: Number,
  referralCode: String,
  referredBy: ObjectId,
  isAgent: Boolean,
  agentLevel: Number,
  bankDetails: Array,
  addresses: Array,
  notificationSettings: Object,
  preferences: Object,
  createdAt: Date,
  updatedAt: Date
}
```

### Transaction Schema
```javascript
{
  _id: ObjectId,
  user: ObjectId,
  type: String,
  category: String,
  service: String,
  amount: Number,
  commission: Number,
  discount: Number,
  totalAmount: Number,
  reference: String,
  externalReference: String,
  status: String,
  recipient: Object,
  details: Object,
  paymentMethod: String,
  paymentGateway: String,
  narration: String,
  metadata: Object,
  commissionPaidTo: Array,
  createdAt: Date,
  updatedAt: Date
}
```

## Environment Variables

### Required Environment Variables
```bash
# Database
MONGODB_URI=mongodb://localhost:27017/nigeria-bills-app

# JWT Secret
JWT_SECRET=your-super-secret-jwt-key-change-this

# Payment Gateways
FLUTTERWAVE_PUBLIC_KEY=your-flutterwave-public-key
FLUTTERWAVE_SECRET_KEY=your-flutterwave-secret-key
FLUTTERWAVE_ENCRYPTION_KEY=your-flutterwave-encryption-key

PAYSTACK_PUBLIC_KEY=your-paystack-public-key
PAYSTACK_SECRET_KEY=your-paystack-secret-key

# VTU APIs
VTU_API_KEY=your-vtu-api-key
VTU_USERNAME=your-vtu-username
VTU_BASE_URL=https://vtu.com.ng/api

# Bill Payment APIs
BILL_API_KEY=your-bill-api-key
BILL_USERNAME=your-bill-username
BILL_BASE_URL=https://api.bills.com.ng

# Email Configuration
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-email-password

# Business Settings
MINIMUM_WALLET_BALANCE=100
MAX_TRANSACTION_LIMIT=50000
DAILY_TRANSACTION_LIMIT=500000
```

## Installation Guide

### Local Development Setup

1. **Clone the repository**
```bash
git clone https://github.com/your-username/nigeria-bills-app.git
cd nigeria-bills-app
```

2. **Install dependencies**
```bash
npm install
```

3. **Set up environment variables**
```bash
cp .env.example .env
# Edit .env file with your actual values
```

4. **Start MongoDB**
```bash
# Using Docker
docker run -d -p 27017:27017 --name mongodb mongo:latest

# Or install locally
# Follow MongoDB installation guide for your OS
```

5. **Start the application**
```bash
# Development mode
npm run dev

# Production mode
npm start
```

### Production Deployment

#### Using Docker
```bash
# Build Docker image
docker build -t nigeria-bills-app .

# Run container
docker run -d \
  -p 3000:3000 \
  -e MONGODB_URI=mongodb://mongodb:27017/nigeria-bills-app \
  -e JWT_SECRET=your-production-secret \
  nigeria-bills-app
```

#### Using PM2
```bash
# Install PM2 globally
npm install -g pm2

# Start application with PM2
pm2 start server.js --name nigeria-bills-app

# Save PM2 configuration
pm2 save

# Setup PM2 to start on boot
pm2 startup
```

#### Using Nginx (Reverse Proxy)
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # SSL Configuration
    listen 443 ssl;
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
}
```

## API Integration Examples

### VTU API Integration
```javascript
const axios = require('axios');

async function buyAirtime(network, amount, phone, reference) {
  try {
    const response = await axios.post(`${process.env.VTU_BASE_URL}/airtime`, {
      api_key: process.env.VTU_API_KEY,
      username: process.env.VTU_USERNAME,
      network: network,
      amount: amount,
      phone: phone,
      ref: reference
    });
    
    return response.data;
  } catch (error) {
    console.error('VTU API Error:', error);
    throw error;
  }
}
```

### Bill Payment API Integration
```javascript
async function payBill(provider, customerId, amount, reference) {
  try {
    const response = await axios.post(`${process.env.BILL_BASE_URL}/pay`, {
      api_key: process.env.BILL_API_KEY,
      provider: provider,
      customer_id: customerId,
      amount: amount,
      ref: reference
    });
    
    return response.data;
  } catch (error) {
    console.error('Bill Payment API Error:', error);
    throw error;
  }
}
```

## Security Best Practices

### 1. Input Validation
- Use Joi for request validation
- Sanitize all user inputs
- Validate phone numbers and email formats

### 2. Authentication & Authorization
- Use strong JWT secrets
- Implement rate limiting
- Use HTTPS in production
- Implement refresh tokens

### 3. Database Security
- Use MongoDB connection with authentication
- Implement proper indexing
- Use MongoDB transactions for multi-document operations

### 4. API Security
- Implement rate limiting
- Use API keys for external integrations
- Implement request signing for sensitive operations
- Use HTTPS everywhere

### 5. Payment Security
- Never store sensitive payment information
- Use PCI DSS compliant payment gateways
- Implement proper webhook verification
- Use encryption for sensitive data

## Monitoring & Logging

### Application Monitoring
```javascript
// Winston logger setup
const winston = require('winston');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' })
  ]
});
```

### Health Check Endpoints
```http
GET /health
```

### Performance Monitoring
- **New Relic**: Application performance monitoring
- **Datadog**: Infrastructure monitoring
- **Sentry**: Error tracking and performance monitoring

## Database Optimization

### Indexes
```javascript
// Create indexes for performance
db.transactions.createIndex({ user: 1, createdAt: -1 });
db.transactions.createIndex({ reference: 1 }, { unique: true });
db.users.createIndex({ email: 1 }, { unique: true });
db.users.createIndex({ phoneNumber: 1 }, { unique: true });
```

### Aggregation Pipelines
```javascript
// User transaction statistics
db.transactions.aggregate([
  { $match: { user: ObjectId("userId") } },
  {
    $group: {
      _id: "$type",
      totalAmount: { $sum: "$amount" },
      count: { $sum: 1 },
      averageAmount: { $avg: "$amount" }
    }
  }
]);
```

## Testing

### Unit Tests
```bash
npm install --save-dev jest supertest

# Run tests
npm test

# Run tests with coverage
npm run test:coverage
```

### Test Example
```javascript
// tests/auth.test.js
const request = require('supertest');
const app = require('../server');

describe('Authentication', () => {
  it('should register a new user', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({
        fullName: 'Test User',
        email: 'test@example.com',
        phoneNumber: '08012345678',
        password: 'password123'
      });
    
    expect(res.statusCode).toBe(201);
    expect(res.body).toHaveProperty('token');
  });
});
```

## Troubleshooting

### Common Issues

#### MongoDB Connection Issues
```bash
# Check MongoDB status
sudo systemctl status mongod

# Restart MongoDB
sudo systemctl restart mongod

# Check logs
tail -f /var/log/mongodb/mongod.log
```

#### Port Already in Use
```bash
# Check what's using port 3000
lsof -i :3000

# Kill the process
kill -9 <PID>
```

#### Memory Issues
```bash
# Check memory usage
free -h
# Or use htop for interactive view
htop
```

## Scaling Strategies

### Horizontal Scaling
- Use load balancer (Nginx)
- Deploy multiple app instances
- Use MongoDB replica set
- Implement caching (Redis)

### Database Sharding
```javascript
// Shard by user ID
sh.shardCollection("nigeria-bills.transactions", { user: 1 });
```

### CDN Integration
- Use Cloudflare for static assets
- Implement browser caching
- Use compression (gzip/brotli)

### Rate Limiting
```javascript
const rateLimit = require('express-rate-limit');

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP'
});
```

## Support

For technical support and questions:
- **Email**: tech@nigeriabills.com
- **GitHub Issues**: https://github.com/your-username/nigeria-bills-app/issues
- **Documentation**: https://docs.nigeriabills.com
- **API Reference**: https://api.nigeriabills.com/docs