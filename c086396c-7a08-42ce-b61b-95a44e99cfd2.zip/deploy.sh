#!/bin/bash

# Nigeria Bills App Deployment Script

echo "🚀 Starting Nigeria Bills App Deployment..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js is not installed. Please install Node.js first.${NC}"
    exit 1
fi

# Check if MongoDB is installed
if ! command -v mongo &> /dev/null; then
    echo -e "${YELLOW}⚠️  MongoDB not found. Please install MongoDB or use MongoDB Atlas${NC}"
fi

# Install dependencies
echo -e "${GREEN}📦 Installing dependencies...${NC}"
npm install

# Create environment file if it doesn't exist
if [ ! -f .env ]; then
    echo -e "${GREEN}📝 Creating .env file...${NC}"
    cp .env.example .env
    echo -e "${YELLOW}⚠️  Please edit .env file with your actual configuration${NC}"
fi

# Create necessary directories
echo -e "${GREEN}📁 Creating directories...${NC}"
mkdir -p logs uploads public/images/networks public/images/bills

# Set permissions
echo -e "${GREEN}🔐 Setting permissions...${NC}"
chmod 755 deploy.sh
chmod 755 server.js

# Start MongoDB if not running
if pgrep mongod > /dev/null; then
    echo -e "${GREEN}✅ MongoDB is already running${NC}"
else
    echo -e "${YELLOW}⚠️  Please start MongoDB manually${NC}"
fi

# Create systemd service for production
if [ "$EUID" -eq 0 ]; then
    echo -e "${GREEN}🖥️  Creating systemd service...${NC}"
    cat > /etc/systemd/system/nigeria-bills.service << EOF
[Unit]
Description=Nigeria Bills App
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/nigeria-bills-app
ExecStart=/usr/bin/node server.js
Restart=on-failure
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=nigeria-bills

[Install]
WantedBy=multi-user.target
EOF
fi

# Test the application
echo -e "${GREEN}🧪 Testing application...${NC}"
node -e "console.log('✅ Node.js version:', process.version)"

# Display next steps
echo -e "\n${GREEN}🎉 Deployment completed successfully!${NC}"
echo -e "\n${YELLOW}Next steps:${NC}"
echo "1. Edit .env file with your actual configuration"
echo "2. Setup MongoDB (local or Atlas)"
echo "3. Configure payment gateways (Flutterwave/Paystack)"
echo "4. Setup VTU and bill payment APIs"
echo "5. Start the application: npm run dev"
echo ""
echo -e "${GREEN}📚 Documentation:${NC}"
echo "- Business Setup Guide: docs/BUSINESS_SETUP.md"
echo "- Technical Documentation: docs/TECHNICAL_DOCUMENTATION.md"
echo "- API Documentation: Available at /api-docs"
echo ""
echo -e "${GREEN}💼 Business Setup:${NC}"
echo "- Register business with CAC"
echo "- Open corporate bank account"
echo "- Setup API accounts with providers"
echo "- Start marketing campaign"
echo ""
echo -e "${GREEN}📞 Support:${NC}"
echo "Email: support@nigeriabills.com"
echo "WhatsApp: +234-XXX-XXX-XXXX"
echo "Website: www.nigeriabills.com"