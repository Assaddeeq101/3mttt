const express = require('express');
const axios = require('axios');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const auth = require('../middleware/auth');
const router = express.Router();

// Get airtime prices
router.get('/prices', async (req, res) => {
  try {
    const prices = {
      mtn: {
        '100': 100,
        '200': 200,
        '500': 500,
        '1000': 1000,
        '1500': 1500,
        '2000': 2000,
        '3000': 3000,
        '5000': 5000
      },
      airtel: {
        '100': 100,
        '200': 200,
        '500': 500,
        '1000': 1000,
        '1500': 1500,
        '2000': 2000,
        '3000': 3000,
        '5000': 5000
      },
      glo: {
        '100': 100,
        '200': 200,
        '500': 500,
        '1000': 1000,
        '1500': 1500,
        '2000': 2000,
        '3000': 3000,
        '5000': 5000
      },
      '9mobile': {
        '100': 100,
        '200': 200,
        '500': 500,
        '1000': 1000,
        '1500': 1500,
        '2000': 2000,
        '3000': 3000,
        '5000': 5000
      }
    };

    // Apply commission/discount
    const discountedPrices = {};
    for (const [provider, amounts] of Object.entries(prices)) {
      discountedPrices[provider] = {};
      for (const [amount, price] of Object.entries(amounts)) {
        const discount = parseFloat(process.env.AIRTIME_COMMISSION || 2.5);
        discountedPrices[provider][amount] = price - (price * discount / 100);
      }
    }

    res.json(discountedPrices);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Buy airtime
router.post('/buy', auth, async (req, res) => {
  try {
    const { network, amount, phoneNumber, paymentMethod } = req.body;

    // Validate input
    if (!network || !amount || !phoneNumber) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    // Validate network
    const validNetworks = ['mtn', 'airtel', 'glo', '9mobile'];
    if (!validNetworks.includes(network.toLowerCase())) {
      return res.status(400).json({ error: 'Invalid network' });
    }

    // Validate amount
    const validAmounts = [100, 200, 500, 1000, 1500, 2000, 3000, 5000];
    if (!validAmounts.includes(parseInt(amount))) {
      return res.status(400).json({ error: 'Invalid amount' });
    }

    // Get user
    const user = await User.findById(req.user.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Calculate price with commission
    const commissionRate = parseFloat(process.env.AIRTIME_COMMISSION || 2.5);
    const sellingPrice = amount - (amount * commissionRate / 100);

    // Check if user has sufficient balance
    if (paymentMethod === 'wallet' && user.walletBalance < sellingPrice) {
      return res.status(400).json({ error: 'Insufficient wallet balance' });
    }

    // Create transaction
    const transaction = new Transaction({
      user: user._id,
      type: 'airtime',
      category: 'purchase',
      service: network.toLowerCase(),
      amount: sellingPrice,
      commission: amount * commissionRate / 100,
      totalAmount: sellingPrice,
      recipient: {
        phoneNumber: phoneNumber
      },
      paymentMethod: paymentMethod,
      narration: `Airtime purchase for ${phoneNumber} on ${network}`,
      status: 'pending'
    });

    await transaction.save();

    // Process VTU purchase
    try {
      const vtuResponse = await processVTUPurchase({
        network: network.toLowerCase(),
        amount: amount,
        phoneNumber: phoneNumber,
        reference: transaction.reference
      });

      if (vtuResponse.success) {
        transaction.status = 'completed';
        transaction.externalReference = vtuResponse.reference;
        
        // Update user balance if paid with wallet
        if (paymentMethod === 'wallet') {
          user.walletBalance -= sellingPrice;
          await user.save();
        }
      } else {
        transaction.status = 'failed';
      }
      
      await transaction.save();
      
      res.json({
        success: vtuResponse.success,
        transactionId: transaction._id,
        reference: transaction.reference,
        message: vtuResponse.message
      });
    } catch (error) {
      transaction.status = 'failed';
      await transaction.save();
      
      res.status(500).json({ error: 'Failed to process airtime purchase' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Process VTU purchase
async function processVTUPurchase({ network, amount, phoneNumber, reference }) {
  try {
    // Mock VTU API call - replace with actual API integration
    const response = {
      success: true,
      reference: 'VTU' + Date.now(),
      message: 'Airtime purchased successfully'
    };
    
    // Actual API call would look like:
    /*
    const response = await axios.post(`${process.env.VTU_BASE_URL}/airtime`, {
      api_key: process.env.VTU_API_KEY,
      username: process.env.VTU_USERNAME,
      network: network,
      amount: amount,
      phone: phoneNumber,
      ref: reference
    });
    */
    
    return response;
  } catch (error) {
    console.error('VTU API Error:', error);
    return {
      success: false,
      message: 'Failed to process airtime purchase'
    };
  }
}

// Get transaction history
router.get('/history', auth, async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    
    const transactions = await Transaction.find({
      user: req.user.userId,
      type: 'airtime'
    })
    .sort({ createdAt: -1 })
    .limit(limit * 1)
    .skip((page - 1) * limit)
    .populate('user', 'fullName email');

    const total = await Transaction.countDocuments({
      user: req.user.userId,
      type: 'airtime'
    });

    res.json({
      transactions,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;