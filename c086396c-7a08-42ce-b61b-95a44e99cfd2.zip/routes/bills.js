const express = require('express');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const auth = require('../middleware/auth');
const router = express.Router();

// Get bill categories and providers
router.get('/categories', async (req, res) => {
  try {
    const categories = {
      electricity: {
        name: 'Electricity',
        providers: [
          { code: 'eko_electricity', name: 'Eko Electricity (EKEDC)', logo: '/images/electricity/eko.png' },
          { code: 'ikeja_electricity', name: 'Ikeja Electricity (IKEDC)', logo: '/images/electricity/ikeja.png' },
          { code: 'abuja_electricity', name: 'Abuja Electricity (AEDC)', logo: '/images/electricity/abuja.png' },
          { code: 'kano_electricity', name: 'Kano Electricity (KEDC)', logo: '/images/electricity/kano.png' },
          { code: 'phcn', name: 'PHCN Postpaid', logo: '/images/electricity/phcn.png' }
        ]
      },
      cable_tv: {
        name: 'Cable TV',
        providers: [
          { code: 'dstv', name: 'DSTV', logo: '/images/cable/dstv.png' },
          { code: 'gotv', name: 'GOtv', logo: '/images/cable/gotv.png' },
          { code: 'startimes', name: 'Startimes', logo: '/images/cable/startimes.png' }
        ]
      },
      internet: {
        name: 'Internet',
        providers: [
          { code: 'smile', name: 'Smile', logo: '/images/internet/smile.png' },
          { code: 'spectranet', name: 'Spectranet', logo: '/images/internet/spectranet.png' },
          { code: 'swift', name: 'Swift', logo: '/images/internet/swift.png' }
        ]
      },
      water: {
        name: 'Water',
        providers: [
          { code: 'lagos_water', name: 'Lagos Water Corporation', logo: '/images/water/lagos.png' },
          { code: 'abuja_water', name: 'Abuja Water Board', logo: '/images/water/abuja.png' }
        ]
      }
    };

    res.json(categories);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get bill packages
router.get('/packages/:provider', async (req, res) => {
  try {
    const { provider } = req.params;
    
    const packages = {
      dstv: [
        { code: 'dstv-premium', name: 'Premium', price: 21000, duration: 'monthly' },
        { code: 'dstv-compact-plus', name: 'Compact Plus', price: 14250, duration: 'monthly' },
        { code: 'dstv-compact', name: 'Compact', price: 9000, duration: 'monthly' },
        { code: 'dstv-family', name: 'Family', price: 5400, duration: 'monthly' },
        { code: 'dstv-access', name: 'Access', price: 2700, duration: 'monthly' }
      ],
      gotv: [
        { code: 'gotv-max', name: 'GOtv Max', price: 4850, duration: 'monthly' },
        { code: 'gotv-jolli', name: 'GOtv Jolli', price: 3300, duration: 'monthly' },
        { code: 'gotv-smallie', name: 'GOtv Smallie', price: 1100, duration: 'monthly' }
      ],
      startimes: [
        { code: 'startimes-smart', name: 'Smart', price: 3200, duration: 'monthly' },
        { code: 'startimes-basic', name: 'Basic', price: 2200, duration: 'monthly' },
        { code: 'startimes-classic', name: 'Classic', price: 2600, duration: 'monthly' }
      ],
      smile: [
        { code: 'smile-10gb', name: '10GB', price: 8000, duration: '30 days' },
        { code: 'smile-20gb', name: '20GB', price: 15000, duration: '30 days' },
        { code: 'smile-50gb', name: '50GB', price: 35000, duration: '30 days' }
      ],
      spectranet: [
        { code: 'spectranet-10gb', name: '10GB', price: 7500, duration: '30 days' },
        { code: 'spectranet-20gb', name: '20GB', price: 14000, duration: '30 days' },
        { code: 'spectranet-50gb', name: '50GB', price: 32000, duration: '30 days' }
      ]
    };

    const providerPackages = packages[provider] || [];
    
    // Apply commission/discount
    const discountedPackages = providerPackages.map(pkg => ({
      ...pkg,
      sellingPrice: pkg.price - (pkg.price * parseFloat(process.env.BILL_COMMISSION || 1.5) / 100)
    }));

    res.json(discountedPackages);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Verify bill details
router.post('/verify', auth, async (req, res) => {
  try {
    const { provider, customerId } = req.body;

    if (!provider || !customerId) {
      return res.status(400).json({ error: 'Provider and customer ID are required' });
    }

    // Mock verification - replace with actual API calls
    const verificationResult = await verifyBillDetails(provider, customerId);

    res.json(verificationResult);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Pay bill
router.post('/pay', auth, async (req, res) => {
  try {
    const { provider, customerId, amount, packageCode, paymentMethod } = req.body;

    if (!provider || !customerId || !amount) {
      return res.status(400).json({ error: 'All required fields must be provided' });
    }

    // Get user
    const user = await User.findById(req.user.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Check if user has sufficient balance
    if (paymentMethod === 'wallet' && user.walletBalance < amount) {
      return res.status(400).json({ error: 'Insufficient wallet balance' });
    }

    // Verify bill details
    const verification = await verifyBillDetails(provider, customerId);
    if (!verification.success) {
      return res.status(400).json({ error: verification.message });
    }

    // Create transaction
    const transaction = new Transaction({
      user: user._id,
      type: 'bill',
      category: 'payment',
      service: provider,
      amount: amount,
      commission: amount * parseFloat(process.env.BILL_COMMISSION || 1.5) / 100,
      totalAmount: amount,
      recipient: {
        accountNumber: customerId,
        name: verification.customerName
      },
      paymentMethod: paymentMethod,
      details: {
        billDetails: {
          provider: provider,
          package: packageCode,
          amount: amount
        }
      },
      narration: `${provider} bill payment for ${customerId}`,
      status: 'pending'
    });

    await transaction.save();

    // Process bill payment
    try {
      const billResponse = await processBillPayment({
        provider: provider,
        customerId: customerId,
        amount: amount,
        reference: transaction.reference
      });

      if (billResponse.success) {
        transaction.status = 'completed';
        transaction.externalReference = billResponse.reference;
        
        // Update user balance if paid with wallet
        if (paymentMethod === 'wallet') {
          user.walletBalance -= amount;
          await user.save();
        }
      } else {
        transaction.status = 'failed';
      }
      
      await transaction.save();
      
      res.json({
        success: billResponse.success,
        transactionId: transaction._id,
        reference: transaction.reference,
        message: billResponse.message
      });
    } catch (error) {
      transaction.status = 'failed';
      await transaction.save();
      
      res.status(500).json({ error: 'Failed to process bill payment' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Verify bill details
async function verifyBillDetails(provider, customerId) {
  try {
    // Mock verification - replace with actual API calls
    const verification = {
      success: true,
      customerName: 'John Doe',
      customerAddress: '123 Main Street, Lagos',
      currentBalance: 0,
      dueAmount: 3200,
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
    };
    
    // Actual API call would look like:
    /*
    const response = await axios.post(`${process.env.BILL_BASE_URL}/verify`, {
      api_key: process.env.BILL_API_KEY,
      provider: provider,
      customer_id: customerId
    });
    */
    
    return verification;
  } catch (error) {
    console.error('Bill Verification Error:', error);
    return {
      success: false,
      message: 'Failed to verify bill details'
    };
  }
}

// Process bill payment
async function processBillPayment({ provider, customerId, amount, reference }) {
  try {
    // Mock bill payment - replace with actual API calls
    const response = {
      success: true,
      reference: 'BILL' + Date.now(),
      message: 'Bill payment processed successfully'
    };
    
    // Actual API call would look like:
    /*
    const response = await axios.post(`${process.env.BILL_BASE_URL}/pay`, {
      api_key: process.env.BILL_API_KEY,
      provider: provider,
      customer_id: customerId,
      amount: amount,
      ref: reference
    });
    */
    
    return response;
  } catch (error) {
    console.error('Bill Payment Error:', error);
    return {
      success: false,
      message: 'Failed to process bill payment'
    };
  }
}

// Get transaction history
router.get('/history', auth, async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    
    const transactions = await Transaction.find({
      user: req.user.userId,
      type: 'bill'
    })
    .sort({ createdAt: -1 })
    .limit(limit * 1)
    .skip((page - 1) * limit)
    .populate('user', 'fullName email');

    const total = await Transaction.countDocuments({
      user: req.user.userId,
      type: 'bill'
    });

    res.json({
      transactions,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;