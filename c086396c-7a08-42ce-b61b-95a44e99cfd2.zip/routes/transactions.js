const express = require('express');
const Transaction = require('../models/Transaction');
const auth = require('../middleware/auth');
const router = express.Router();

// Get all transactions
router.get('/', auth, async (req, res) => {
  try {
    const { page = 1, limit = 10, type, status, startDate, endDate } = req.query;
    
    const query = { user: req.user.userId };
    
    if (type) query.type = type;
    if (status) query.status = status;
    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) query.createdAt.$gte = new Date(startDate);
      if (endDate) query.createdAt.$lte = new Date(endDate);
    }

    const transactions = await Transaction.find(query)
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .populate('user', 'fullName email');

    const total = await Transaction.countDocuments(query);

    res.json({
      transactions,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get transaction by ID
router.get('/:id', auth, async (req, res) => {
  try {
    const transaction = await Transaction.findOne({
      _id: req.params.id,
      user: req.user.userId
    }).populate('user', 'fullName email');

    if (!transaction) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    res.json(transaction);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get transaction statistics
router.get('/stats/summary', auth, async (req, res) => {
  try {
    const { period = '30d' } = req.query;
    
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(period));

    const stats = await Transaction.aggregate([
      {
        $match: {
          user: req.user.userId,
          createdAt: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: '$type',
          totalAmount: { $sum: '$amount' },
          totalTransactions: { $sum: 1 },
          averageAmount: { $avg: '$amount' }
        }
      }
    ]);

    const totalStats = await Transaction.aggregate([
      {
        $match: {
          user: req.user.userId,
          createdAt: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: null,
          totalAmount: { $sum: '$amount' },
          totalTransactions: { $sum: 1 }
        }
      }
    ]);

    res.json({
      byType: stats,
      total: totalStats[0] || { totalAmount: 0, totalTransactions: 0 }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Generate receipt
router.get('/:id/receipt', auth, async (req, res) => {
  try {
    const transaction = await Transaction.findOne({
      _id: req.params.id,
      user: req.user.userId
    }).populate('user', 'fullName email phoneNumber');

    if (!transaction) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    // Generate receipt data
    const receipt = {
      transactionId: transaction._id,
      reference: transaction.reference,
      date: transaction.createdAt,
      customerName: transaction.user.fullName,
      customerEmail: transaction.user.email,
      customerPhone: transaction.user.phoneNumber,
      type: transaction.type,
      service: transaction.service,
      amount: transaction.amount,
      commission: transaction.commission,
      totalAmount: transaction.totalAmount,
      status: transaction.status,
      narration: transaction.narration,
      recipient: transaction.recipient
    };

    res.json(receipt);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;