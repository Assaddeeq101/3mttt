const express = require('express');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const auth = require('../middleware/auth');
const router = express.Router();

// Get user dashboard
router.get('/dashboard', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId);
    
    // Get recent transactions
    const recentTransactions = await Transaction.find({ user: user._id })
      .sort({ createdAt: -1 })
      .limit(5);

    // Get monthly stats
    const startOfMonth = new Date();
    startOfMonth.setDate(1);
    startOfMonth.setHours(0, 0, 0, 0);

    const monthlyStats = await Transaction.aggregate([
      {
        $match: {
          user: user._id,
          createdAt: { $gte: startOfMonth }
        }
      },
      {
        $group: {
          _id: '$type',
          totalAmount: { $sum: '$amount' },
          count: { $sum: 1 }
        }
      }
    ]);

    // Get referral stats
    const referrals = await User.find({ referredBy: user._id });
    const referralStats = {
      totalReferrals: referrals.length,
      activeReferrals: referrals.filter(r => r.lastLogin).length,
      referralEarnings: referrals.reduce((sum, r) => sum + (r.commissionBalance || 0), 0)
    };

    res.json({
      user: {
        id: user._id,
        fullName: user.fullName,
        email: user.email,
        phoneNumber: user.phoneNumber,
        walletBalance: user.walletBalance,
        commissionBalance: user.commissionBalance,
        referralCode: user.referralCode,
        isVerified: user.isVerified,
        isAgent: user.isAgent
      },
      recentTransactions,
      monthlyStats,
      referralStats
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get referrals
router.get('/referrals', auth, async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    
    const referrals = await User.find({ referredBy: req.user.userId })
      .select('fullName email phoneNumber createdAt walletBalance')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await User.countDocuments({ referredBy: req.user.userId });

    res.json({
      referrals,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update notification preferences
router.put('/notifications', auth, async (req, res) => {
  try {
    const updates = req.body;
    
    const user = await User.findByIdAndUpdate(
      req.user.userId,
      { notificationSettings: updates },
      { new: true, runValidators: true }
    ).select('notificationSettings');

    res.json(user.notificationSettings);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update preferences
router.put('/preferences', auth, async (req, res) => {
  try {
    const updates = req.body;
    
    const user = await User.findByIdAndUpdate(
      req.user.userId,
      { preferences: updates },
      { new: true, runValidators: true }
    ).select('preferences');

    res.json(user.preferences);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;