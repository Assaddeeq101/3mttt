const express = require('express');
const DataPlan = require('../models/DataPlan');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const auth = require('../middleware/auth');
const router = express.Router();

// Get data plans by network
router.get('/plans/:network', async (req, res) => {
  try {
    const { network } = req.params;
    const validNetworks = ['mtn', 'airtel', 'glo', '9mobile'];
    
    if (!validNetworks.includes(network.toLowerCase())) {
      return res.status(400).json({ error: 'Invalid network' });
    }

    const plans = await DataPlan.find({
      provider: network.toLowerCase(),
      isActive: true
    }).sort({ price: 1 });

    res.json(plans);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get all data plans
router.get('/plans', async (req, res) => {
  try {
    const plans = await DataPlan.find({ isActive: true })
      .sort({ provider: 1, price: 1 });

    // Group by provider
    const groupedPlans = plans.reduce((acc, plan) => {
      if (!acc[plan.provider]) {
        acc[plan.provider] = [];
      }
      acc[plan.provider].push(plan);
      return acc;
    }, {});

    res.json(groupedPlans);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Buy data bundle
router.post('/buy', auth, async (req, res) => {
  try {
    const { planId, phoneNumber, paymentMethod } = req.body;

    if (!planId || !phoneNumber) {
      return res.status(400).json({ error: 'Plan ID and phone number are required' });
    }

    // Get data plan
    const plan = await DataPlan.findById(planId);
    if (!plan) {
      return res.status(404).json({ error: 'Data plan not found' });
    }

    // Get user
    const user = await User.findById(req.user.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Check if user has sufficient balance
    if (paymentMethod === 'wallet' && user.walletBalance < plan.sellingPrice) {
      return res.status(400).json({ error: 'Insufficient wallet balance' });
    }

    // Create transaction
    const transaction = new Transaction({
      user: user._id,
      type: 'data',
      category: 'purchase',
      service: plan.provider,
      amount: plan.sellingPrice,
      commission: plan.commission,
      totalAmount: plan.sellingPrice,
      recipient: {
        phoneNumber: phoneNumber
      },
      paymentMethod: paymentMethod,
      details: {
        dataPlan: {
          name: plan.name,
          size: plan.size,
          duration: plan.duration,
          price: plan.price
        }
      },
      narration: `Data purchase: ${plan.name} for ${phoneNumber}`,
      status: 'pending'
    });

    await transaction.save();

    // Process data purchase
    try {
      const dataResponse = await processDataPurchase({
        network: plan.provider,
        planCode: plan.planCode,
        phoneNumber: phoneNumber,
        reference: transaction.reference
      });

      if (dataResponse.success) {
        transaction.status = 'completed';
        transaction.externalReference = dataResponse.reference;
        
        // Update user balance if paid with wallet
        if (paymentMethod === 'wallet') {
          user.walletBalance -= plan.sellingPrice;
          await user.save();
        }
      } else {
        transaction.status = 'failed';
      }
      
      await transaction.save();
      
      res.json({
        success: dataResponse.success,
        transactionId: transaction._id,
        reference: transaction.reference,
        message: dataResponse.message
      });
    } catch (error) {
      transaction.status = 'failed';
      await transaction.save();
      
      res.status(500).json({ error: 'Failed to process data purchase' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Process data purchase
async function processDataPurchase({ network, planCode, phoneNumber, reference }) {
  try {
    // Mock data API call - replace with actual API integration
    const response = {
      success: true,
      reference: 'DATA' + Date.now(),
      message: 'Data bundle activated successfully'
    };
    
    // Actual API call would look like:
    /*
    const response = await axios.post(`${process.env.VTU_BASE_URL}/data`, {
      api_key: process.env.VTU_API_KEY,
      username: process.env.VTU_USERNAME,
      network: network,
      plan_code: planCode,
      phone: phoneNumber,
      ref: reference
    });
    */
    
    return response;
  } catch (error) {
    console.error('Data API Error:', error);
    return {
      success: false,
      message: 'Failed to process data purchase'
    };
  }
}

// Get transaction history
router.get('/history', auth, async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    
    const transactions = await Transaction.find({
      user: req.user.userId,
      type: 'data'
    })
    .sort({ createdAt: -1 })
    .limit(limit * 1)
    .skip((page - 1) * limit)
    .populate('user', 'fullName email');

    const total = await Transaction.countDocuments({
      user: req.user.userId,
      type: 'data'
    });

    res.json({
      transactions,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get data usage analytics
router.get('/analytics', auth, async (req, res) => {
  try {
    const { period = '30d' } = req.query;
    
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(period));

    const analytics = await Transaction.aggregate([
      {
        $match: {
          user: req.user.userId,
          type: 'data',
          createdAt: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: {
            provider: '$service',
            month: { $month: '$createdAt' }
          },
          totalAmount: { $sum: '$amount' },
          totalTransactions: { $sum: 1 }
        }
      },
      {
        $sort: { '_id.month': 1 }
      }
    ]);

    res.json(analytics);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;