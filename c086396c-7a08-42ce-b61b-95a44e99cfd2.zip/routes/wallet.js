const express = require('express');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const auth = require('../middleware/auth');
const router = express.Router();

// Get wallet balance
router.get('/balance', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId);
    res.json({
      walletBalance: user.walletBalance,
      commissionBalance: user.commissionBalance
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Fund wallet
router.post('/fund', auth, async (req, res) => {
  try {
    const { amount, paymentMethod, paymentGateway } = req.body;

    if (!amount || amount < 100) {
      return res.status(400).json({ error: 'Minimum funding amount is ₦100' });
    }

    const user = await User.findById(req.user.userId);
    
    // Create funding transaction
    const transaction = new Transaction({
      user: user._id,
      type: 'wallet_funding',
      category: 'funding',
      service: 'wallet',
      amount: amount,
      totalAmount: amount,
      paymentMethod: paymentMethod,
      paymentGateway: paymentGateway,
      narration: `Wallet funding of ₦${amount}`,
      status: 'pending'
    });

    await transaction.save();

    // Generate payment link (mock implementation)
    const paymentLink = await generatePaymentLink({
      amount: amount,
      email: user.email,
      reference: transaction.reference,
      gateway: paymentGateway
    });

    res.json({
      transactionId: transaction._id,
      reference: transaction.reference,
      paymentLink: paymentLink.url
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Withdraw from wallet
router.post('/withdraw', auth, async (req, res) => {
  try {
    const { amount, bankAccount, narration } = req.body;

    if (!amount || amount < 100) {
      return res.status(400).json({ error: 'Minimum withdrawal amount is ₦100' });
    }

    const user = await User.findById(req.user.userId);
    
    if (user.walletBalance < amount) {
      return res.status(400).json({ error: 'Insufficient wallet balance' });
    }

    // Create withdrawal transaction
    const transaction = new Transaction({
      user: user._id,
      type: 'wallet_withdrawal',
      category: 'withdrawal',
      service: 'bank_transfer',
      amount: amount,
      totalAmount: amount,
      paymentMethod: 'bank_transfer',
      narration: narration || `Wallet withdrawal of ₦${amount}`,
      status: 'pending'
    });

    await transaction.save();

    // Process withdrawal (mock implementation)
    const withdrawalResult = await processWithdrawal({
      amount: amount,
      bankAccount: bankAccount,
      reference: transaction.reference
    });

    if (withdrawalResult.success) {
      user.walletBalance -= amount;
      await user.save();
      
      transaction.status = 'completed';
      transaction.externalReference = withdrawalResult.reference;
      await transaction.save();
    }

    res.json({
      success: withdrawalResult.success,
      transactionId: transaction._id,
      reference: transaction.reference,
      message: withdrawalResult.message
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get transaction history
router.get('/transactions', auth, async (req, res) => {
  try {
    const { page = 1, limit = 10, type } = req.query;
    
    const query = { user: req.user.userId };
    if (type) {
      query.type = type;
    }

    const transactions = await Transaction.find(query)
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .populate('user', 'fullName email');

    const total = await Transaction.countDocuments(query);

    res.json({
      transactions,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Generate payment link (mock implementation)
async function generatePaymentLink({ amount, email, reference, gateway }) {
  try {
    // Mock payment link generation
    const paymentLink = {
      url: `https://paystack.com/pay/${reference}`,
      reference: reference
    };
    
    return paymentLink;
  } catch (error) {
    console.error('Payment Link Error:', error);
    return {
      url: '#',
      reference: reference
    };
  }
}

// Process withdrawal (mock implementation)
async function processWithdrawal({ amount, bankAccount, reference }) {
  try {
    // Mock withdrawal processing
    const withdrawal = {
      success: true,
      reference: 'WD' + Date.now(),
      message: 'Withdrawal processed successfully'
    };
    
    return withdrawal;
  } catch (error) {
    console.error('Withdrawal Error:', error);
    return {
      success: false,
      message: 'Failed to process withdrawal'
    };
  }
}

module.exports = router;