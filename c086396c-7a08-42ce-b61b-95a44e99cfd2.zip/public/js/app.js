class NigeriaBillsApp {
  constructor() {
    this.currentUser = null;
    this.currentPage = 'dashboard';
    this.selectedNetwork = 'mtn';
    this.selectedAmount = 0;
    this.selectedDataPlan = null;
    this.selectedBillCategory = null;
    this.selectedBillProvider = null;
    this.transactionPin = null;
    
    this.init();
  }

  async init() {
    await this.hideSplashScreen();
    this.setupEventListeners();
    this.loadUserData();
    this.setupNetworkSelectors();
    this.setupAmountSelectors();
  }

  async hideSplashScreen() {
    await new Promise(resolve => setTimeout(resolve, 2000));
    const splash = document.getElementById('splash-screen');
    if (splash) {
      splash.style.opacity = '0';
      setTimeout(() => splash.style.display = 'none', 500);
    }
  }

  setupEventListeners() {
    // Navigation
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const page = item.getAttribute('data-page');
        this.showPage(page);
      });
    });

    // Back buttons
    document.querySelectorAll('.back-btn').forEach(btn => {
      btn.addEventListener('click', () => this.showPage('dashboard'));
    });

    // Network selectors
    document.querySelectorAll('.network-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.network-btn').forEach(b => b.classList.remove('active'));
        e.target.closest('.network-btn').classList.add('active');
        this.selectedNetwork = e.target.closest('.network-btn').getAttribute('data-network');
        this.loadDataPlans();
      });
    });

    // Amount buttons
    document.querySelectorAll('.amount-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.amount-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        this.selectedAmount = parseInt(e.target.getAttribute('data-amount'));
        this.updateAirtimeSummary();
      });
    });

    // Input listeners
    this.setupInputListeners();
  }

  setupInputListeners() {
    // Airtime phone input
    const airtimePhone = document.getElementById('airtime-phone');
    if (airtimePhone) {
      airtimePhone.addEventListener('input', (e) => {
        e.target.value = e.target.value.replace(/\D/g, '').slice(0, 11);
      });
    }

    // Data phone input
    const dataPhone = document.getElementById('data-phone');
    if (dataPhone) {
      dataPhone.addEventListener('input', (e) => {
        e.target.value = e.target.value.replace(/\D/g, '').slice(0, 11);
      });
    }

    // Amount inputs
    const airtimeAmount = document.getElementById('airtime-amount');
    if (airtimeAmount) {
      airtimeAmount.addEventListener('input', (e) => {
        this.selectedAmount = parseInt(e.target.value) || 0;
        this.updateAirtimeSummary();
      });
    }

    const billAmount = document.getElementById('bill-amount');
    if (billAmount) {
      billAmount.addEventListener('input', (e) => {
        this.updateBillSummary();
      });
    }
  }

  setupNetworkSelectors() {
    document.querySelectorAll('.network-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const container = e.target.closest('.network-selector');
        container.querySelectorAll('.network-btn').forEach(b => b.classList.remove('active'));
        e.target.closest('.network-btn').classList.add('active');
      });
    });
  }

  setupAmountSelectors() {
    document.querySelectorAll('.amount-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const container = e.target.closest('.amount-selector');
        container.querySelectorAll('.amount-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
      });
    });
  }

  showPage(page) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    
    // Show selected page
    const selectedPage = document.getElementById(page);
    if (selectedPage) {
      selectedPage.classList.add('active');
      this.currentPage = page;
      
      // Update navigation
      document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
      });
      document.querySelector(`[data-page="${page}"]`)?.classList.add('active');
    }

    // Load page-specific data
    switch(page) {
      case 'dashboard':
        this.loadDashboardData();
        break;
      case 'airtime':
        this.loadAirtimeData();
        break;
      case 'data':
        this.loadDataPlans();
        break;
      case 'bills':
        this.loadBillCategories();
        break;
      case 'wallet':
        this.loadWalletData();
        break;
    }
  }

  async loadUserData() {
    try {
      // Mock user data - replace with actual API call
      this.currentUser = {
        id: 1,
        fullName: 'John Doe',
        email: 'john@example.com',
        walletBalance: 15000.00,
        commissionBalance: 2500.00,
        referralCode: 'ABC123'
      };
      
      this.updateUserInterface();
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  }

  updateUserInterface() {
    if (this.currentUser) {
      document.getElementById('wallet-balance').textContent = this.formatCurrency(this.currentUser.walletBalance);
      document.getElementById('wallet-display-balance').textContent = this.formatCurrency(this.currentUser.walletBalance);
    }
  }

  formatCurrency(amount) {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 2
    }).format(amount).replace('NGN', '');
  }

  loadDashboardData() {
    // Load recent transactions
    const transactions = [
      {
        type: 'airtime',
        service: 'MTN',
        amount: 500,
        date: new Date(),
        status: 'completed'
      },
      {
        type: 'data',
        service: 'Airtel',
        amount: 1000,
        date: new Date(),
        status: 'completed'
      }
    ];

    this.displayRecentTransactions(transactions);
  }

  displayRecentTransactions(transactions) {
    const container = document.getElementById('recent-transactions-list');
    if (!container) return;

    if (transactions.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <i class="fas fa-clock"></i>
          <p>No recent transactions</p>
        </div>
      `;
      return;
    }

    container.innerHTML = transactions.map(transaction => `
      <div class="transaction-item">
        <div class="transaction-icon">
          <i class="fas fa-${this.getTransactionIcon(transaction.type)}"></i>
        </div>
        <div class="transaction-details">
          <h4>${transaction.service} ${transaction.type}</h4>
          <p>${this.formatCurrency(transaction.amount)}</p>
        </div>
        <div class="transaction-status">
          <span class="status-badge ${transaction.status}">${transaction.status}</span>
        </div>
      </div>
    `).join('');
  }

  getTransactionIcon(type) {
    const icons = {
      airtime: 'phone',
      data: 'wifi',
      bill: 'file-invoice-dollar',
      wallet: 'wallet'
    };
    return icons[type] || 'circle';
  }

  loadAirtimeData() {
    // Load airtime prices
    const prices = {
      mtn: { 100: 97.5, 200: 195, 500: 487.5, 1000: 975, 1500: 1462.5, 2000: 1950, 3000: 2925, 5000: 4875 },
      airtel: { 100: 97.5, 200: 195, 500: 487.5, 1000: 975, 1500: 1462.5, 2000: 1950, 3000: 2925, 5000: 4875 },
      glo: { 100: 97.5, 200: 195, 500: 487.5, 1000: 975, 1500: 1462.5, 2000: 1950, 3000: 2925, 5000: 4875 },
      '9mobile': { 100: 97.5, 200: 195, 500: 487.5, 1000: 975, 1500: 1462.5, 2000: 1950, 3000: 2925, 5000: 4875 }
    };
    
    this.updateAirtimeSummary();
  }

  updateAirtimeSummary() {
    const amount = this.selectedAmount;
    const discount = amount * 0.025; // 2.5% discount
    const total = amount - discount;

    document.getElementById('airtime-summary-amount').textContent = this.formatCurrency(amount);
    document.getElementById('airtime-summary-discount').textContent = this.formatCurrency(discount);
    document.getElementById('airtime-summary-total').textContent = this.formatCurrency(total);
  }

  loadDataPlans() {
    const plans = {
      mtn: [
        { name: '1GB Daily', size: '1GB', duration: '1 day', price: 350, sellingPrice: 339.5 },
        { name: '2GB Weekly', size: '2GB', duration: '7 days', price: 500, sellingPrice: 485 },
        { name: '3GB Monthly', size: '3GB', duration: '30 days', price: 1000, sellingPrice: 970 },
        { name: '5GB Monthly', size: '5GB', duration: '30 days', price: 1500, sellingPrice: 1455 }
      ],
      airtel: [
        { name: '1.5GB Daily', size: '1.5GB', duration: '1 day', price: 400, sellingPrice: 388 },
        { name: '3GB Weekly', size: '3GB', duration: '7 days', price: 600, sellingPrice: 582 },
        { name: '4GB Monthly', size: '4GB', duration: '30 days', price: 1200, sellingPrice: 1164 },
        { name: '6GB Monthly', size: '6GB', duration: '30 days', price: 1800, sellingPrice: 1746 }
      ],
      glo: [
        { name: '2GB Daily', size: '2GB', duration: '1 day', price: 500, sellingPrice: 485 },
        { name: '4GB Weekly', size: '4GB', duration: '7 days', price: 800, sellingPrice: 776 },
        { name: '6GB Monthly', size: '6GB', duration: '30 days', price: 1500, sellingPrice: 1455 },
        { name: '10GB Monthly', size: '10GB', duration: '30 days', price: 2500, sellingPrice: 2425 }
      ],
      '9mobile': [
        { name: '1GB Daily', size: '1GB', duration: '1 day', price: 300, sellingPrice: 291 },
        { name: '2GB Weekly', size: '2GB', duration: '7 days', price: 500, sellingPrice: 485 },
        { name: '4GB Monthly', size: '4GB', duration: '30 days', price: 1200, sellingPrice: 1164 },
        { name: '8GB Monthly', size: '8GB', duration: '30 days', price: 2000, sellingPrice: 1940 }
      ]
    };

    const networkPlans = plans[this.selectedNetwork] || [];
    this.displayDataPlans(networkPlans);
  }

  displayDataPlans(plans) {
    const container = document.getElementById('data-plans');
    if (!container) return;

    container.innerHTML = plans.map(plan => `
      <div class="data-plan" onclick="app.selectDataPlan('${plan.name}', ${plan.sellingPrice})">
        <div class="data-plan-header">
          <span class="data-plan-name">${plan.name}</span>
          <span class="data-plan-price">₦${plan.sellingPrice}</span>
        </div>
        <div class="data-plan-details">
          ${plan.size} • ${plan.duration}
        </div>
      </div>
    `).join('');
  }

  selectDataPlan(name, price) {
    this.selectedDataPlan = { name, price };
    document.querySelectorAll('.data-plan').forEach(plan => plan.classList.remove('active'));
    event.target.closest('.data-plan').classList.add('active');
    this.updateDataSummary();
  }

  updateDataSummary() {
    if (!this.selectedDataPlan) return;

    document.getElementById('data-summary-plan').textContent = this.selectedDataPlan.name;
    document.getElementById('data-summary-amount').textContent = this.formatCurrency(this.selectedDataPlan.price);
    
    const discount = this.selectedDataPlan.price * 0.03; // 3% discount
    document.getElementById('data-summary-discount').textContent = this.formatCurrency(discount);
    document.getElementById('data-summary-total').textContent = this.formatCurrency(this.selectedDataPlan.price);
  }

  loadBillCategories() {
    const categories = {
      electricity: [
        { code: 'eko_electricity', name: 'Eko Electricity (EKEDC)', logo: '/images/electricity/eko.png' },
        { code: 'ikeja_electricity', name: 'Ikeja Electricity (IKEDC)', logo: '/images/electricity/ikeja.png' },
        { code: 'abuja_electricity', name: 'Abuja Electricity (AEDC)', logo: '/images/electricity/abuja.png' }
      ],
      cable_tv: [
        { code: 'dstv', name: 'DSTV', logo: '/images/cable/dstv.png' },
        { code: 'gotv', name: 'GOtv', logo: '/images/cable/gotv.png' },
        { code: 'startimes', name: 'Startimes', logo: '/images/cable/startimes.png' }
      ],
      internet: [
        { code: 'smile', name: 'Smile', logo: '/images/internet/smile.png' },
        { code: 'spectranet', name: 'Spectranet', logo: '/images/internet/spectranet.png' }
      ]
    };

    this.displayBillCategories(categories);
  }

  displayBillCategories(categories) {
    document.querySelectorAll('.bill-category').forEach(category => {
      category.addEventListener('click', (e) => {
        const categoryType = e.target.closest('.bill-category').getAttribute('data-category');
        this.showBillForm(categoryType);
      });
    });
  }

  showBillForm(category) {
    this.selectedBillCategory = category;
    const form = document.getElementById('bills-form');
    if (form) {
      form.style.display = 'block';
      this.loadBillProviders(category);
    }
  }

  loadBillProviders(category) {
    const providers = {
      electricity: [
        { code: 'eko_electricity', name: 'Eko Electricity (EKEDC)' },
        { code: 'ikeja_electricity', name: 'Ikeja Electricity (IKEDC)' },
        { code: 'abuja_electricity', name: 'Abuja Electricity (AEDC)' }
      ],
      cable_tv: [
        { code: 'dstv', name: 'DSTV' },
        { code: 'gotv', name: 'GOtv' },
        { code: 'startimes', name: 'Startimes' }
      ],
      internet: [
        { code: 'smile', name: 'Smile' },
        { code: 'spectranet', name: 'Spectranet' }
      ]
    };

    const select = document.getElementById('bill-provider');
    if (select) {
      select.innerHTML = '<option value="">Select Provider</option>' +
        providers[category].map(provider => 
          `<option value="${provider.code}">${provider.name}</option>`
        ).join('');
    }
  }

  updateBillSummary() {
    const amount = parseFloat(document.getElementById('bill-amount')?.value || 0);
    const commission = amount * 0.015; // 1.5% commission
    
    document.getElementById('bill-summary-amount').textContent = this.formatCurrency(amount);
    document.getElementById('bill-summary-commission').textContent = this.formatCurrency(commission);
    document.getElementById('bill-summary-total').textContent = this.formatCurrency(amount);
  }

  loadWalletData() {
    // Load wallet transactions
    this.loadWalletTransactions();
  }

  loadWalletTransactions() {
    const transactions = [
      {
        type: 'wallet_funding',
        amount: 5000,
        date: new Date(),
        status: 'completed'
      },
      {
        type: 'wallet_withdrawal',
        amount: 2000,
        date: new Date(),
        status: 'completed'
      }
    ];

    this.displayWalletTransactions(transactions);
  }

  displayWalletTransactions(transactions) {
    const container = document.getElementById('wallet-transactions-list');
    if (!container) return;

    container.innerHTML = transactions.map(transaction => `
      <div class="transaction-item">
        <div class="transaction-icon">
          <i class="fas fa-${transaction.type === 'wallet_funding' ? 'arrow-down' : 'arrow-up'}"></i>
        </div>
        <div class="transaction-details">
          <h4>${transaction.type.replace('_', ' ')}</h4>
          <p>${this.formatCurrency(transaction.amount)}</p>
        </div>
        <div class="transaction-status">
          <span class="status-badge ${transaction.status}">${transaction.status}</span>
        </div>
      </div>
    `).join('');
  }

  showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('active');
    }
  }

  closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('active');
    }
  }

  async buyAirtime() {
    const phoneNumber = document.getElementById('airtime-phone')?.value;
    const amount = this.selectedAmount;

    if (!phoneNumber || phoneNumber.length !== 11) {
      alert('Please enter a valid phone number');
      return;
    }

    if (!amount || amount < 100) {
      alert('Please select a valid amount');
      return;
    }

    this.showModal('pin-modal');
  }

  async buyData() {
    const phoneNumber = document.getElementById('data-phone')?.value;

    if (!phoneNumber || phoneNumber.length !== 11) {
      alert('Please enter a valid phone number');
      return;
    }

    if (!this.selectedDataPlan) {
      alert('Please select a data plan');
      return;
    }

    this.showModal('pin-modal');
  }

  async payBill() {
    const customerId = document.getElementById('bill-customer-id')?.value;
    const amount = parseFloat(document.getElementById('bill-amount')?.value || 0);

    if (!customerId) {
      alert('Please enter customer ID');
      return;
    }

    if (!amount || amount < 100) {
      alert('Please enter a valid amount');
      return;
    }

    this.showModal('pin-modal');
  }

  async confirmTransaction() {
    const pin = document.getElementById('transaction-pin')?.value;
    
    if (!pin || pin.length !== 4) {
      alert('Please enter a valid 4-digit PIN');
      return;
    }

    // Mock transaction processing
    this.closeModal('pin-modal');
    
    // Simulate processing
    setTimeout(() => {
      this.showModal('success-modal');
      document.getElementById('success-message').textContent = 'Transaction completed successfully!';
    }, 1000);
  }

  // Utility methods
  formatCurrency(amount) {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 2
    }).format(amount).replace('NGN', '');
  }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  window.app = new NigeriaBillsApp();
});