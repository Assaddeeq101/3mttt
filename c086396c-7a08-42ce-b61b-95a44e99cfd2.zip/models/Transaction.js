const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  type: {
    type: String,
    required: true,
    enum: ['airtime', 'data', 'bill', 'wallet_funding', 'wallet_withdrawal', 'commission', 'refund']
  },
  category: {
    type: String,
    required: true,
    enum: ['purchase', 'payment', 'transfer', 'funding', 'withdrawal', 'commission', 'refund']
  },
  service: {
    type: String,
    required: true,
    enum: ['mtn', 'airtel', 'glo', '9mobile', 'dstv', 'gotv', 'startimes', 'eko_electricity', 'ikeja_electricity', 'abuja_electricity', 'kano_electricity', 'phcn', 'smile', 'spectranet', 'swift', 'other']
  },
  amount: {
    type: Number,
    required: true,
    min: 0
  },
  commission: {
    type: Number,
    default: 0,
    min: 0
  },
  discount: {
    type: Number,
    default: 0,
    min: 0
  },
  totalAmount: {
    type: Number,
    required: true,
    min: 0
  },
  reference: {
    type: String,
    required: true,
    unique: true
  },
  externalReference: {
    type: String,
    required: false
  },
  status: {
    type: String,
    required: true,
    enum: ['pending', 'processing', 'completed', 'failed', 'cancelled', 'refunded'],
    default: 'pending'
  },
  recipient: {
    phoneNumber: String,
    email: String,
    name: String,
    meterNumber: String,
    decoderNumber: String,
    accountNumber: String
  },
  details: {
    dataPlan: {
      name: String,
      size: String,
      duration: String,
      price: Number
    },
    billDetails: {
      provider: String,
      package: String,
      amount: Number,
      dueDate: Date
    },
    electricityDetails: {
      meterType: String,
      meterNumber: String,
      customerName: String,
      address: String,
      units: Number
    }
  },
  paymentMethod: {
    type: String,
    enum: ['wallet', 'card', 'bank_transfer', 'ussd', 'qr_code'],
    required: true
  },
  paymentGateway: {
    type: String,
    enum: ['flutterwave', 'paystack', 'moniepoint', 'opay', 'palmpay'],
    required: false
  },
  narration: {
    type: String,
    required: true
  },
  metadata: {
    ipAddress: String,
    userAgent: String,
    deviceId: String,
    location: {
      lat: Number,
      lng: Number
    }
  },
  commissionPaidTo: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    amount: Number,
    level: Number
  }],
  refundReason: String,
  refundAmount: Number,
  refundDate: Date,
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Indexes for performance
transactionSchema.index({ user: 1, createdAt: -1 });
transactionSchema.index({ reference: 1 });
transactionSchema.index({ status: 1 });
transactionSchema.index({ type: 1 });
transactionSchema.index({ 'recipient.phoneNumber': 1 });

// Generate unique reference
transactionSchema.pre('save', function(next) {
  if (!this.reference) {
    this.reference = 'TXN' + Date.now() + Math.random().toString(36).substr(2, 5).toUpperCase();
  }
  next();
});

// Update updatedAt
transactionSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Transaction', transactionSchema);