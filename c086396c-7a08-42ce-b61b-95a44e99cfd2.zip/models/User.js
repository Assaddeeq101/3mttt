const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  fullName: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  phoneNumber: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  password: {
    type: String,
    required: true,
    minlength: 6
  },
  bvn: {
    type: String,
    required: false,
    trim: true
  },
  nin: {
    type: String,
    required: false,
    trim: true
  },
  isVerified: {
    type: Boolean,
    default: false
  },
  verificationLevel: {
    type: Number,
    default: 1,
    min: 1,
    max: 3
  },
  walletBalance: {
    type: Number,
    default: 0,
    min: 0
  },
  commissionBalance: {
    type: Number,
    default: 0,
    min: 0
  },
  referralCode: {
    type: String,
    unique: true
  },
  referredBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  isAgent: {
    type: Boolean,
    default: false
  },
  agentLevel: {
    type: Number,
    default: 0,
    min: 0,
    max: 5
  },
  transactionPin: {
    type: String,
    required: false
  },
  bankDetails: [{
    bankName: String,
    accountNumber: String,
    accountName: String,
    isDefault: Boolean
  }],
  addresses: [{
    type: {
      type: String,
      enum: ['home', 'work', 'billing']
    },
    street: String,
    city: String,
    state: String,
    lga: String,
    isDefault: Boolean
  }],
  notificationSettings: {
    email: { type: Boolean, default: true },
    sms: { type: Boolean, default: true },
    push: { type: Boolean, default: true },
    whatsapp: { type: Boolean, default: false }
  },
  preferences: {
    language: { type: String, default: 'en' },
    currency: { type: String, default: 'NGN' },
    theme: { type: String, default: 'light' }
  },
  lastLogin: Date,
  loginAttempts: { type: Number, default: 0 },
  lockUntil: Date,
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Indexes for performance
userSchema.index({ email: 1 });
userSchema.index({ phoneNumber: 1 });
userSchema.index({ referralCode: 1 });

// Pre-save middleware to hash password
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Method to compare password
userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Method to generate referral code
userSchema.methods.generateReferralCode = function() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 6; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
};

// Generate referral code before saving
userSchema.pre('save', function(next) {
  if (!this.referralCode) {
    this.referralCode = this.generateReferralCode();
  }
  next();
});

module.exports = mongoose.model('User', userSchema);