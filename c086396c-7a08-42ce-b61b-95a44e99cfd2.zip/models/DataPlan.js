const mongoose = require('mongoose');

const dataPlanSchema = new mongoose.Schema({
  provider: {
    type: String,
    required: true,
    enum: ['mtn', 'airtel', 'glo', '9mobile']
  },
  name: {
    type: String,
    required: true
  },
  size: {
    type: String,
    required: true
  },
  duration: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    required: true,
    min: 0
  },
  sellingPrice: {
    type: Number,
    required: true,
    min: 0
  },
  commission: {
    type: Number,
    default: 0,
    min: 0
  },
  discount: {
    type: Number,
    default: 0,
    min: 0
  },
  isActive: {
    type: Boolean,
    default: true
  },
  planCode: {
    type: String,
    required: true,
    unique: true
  },
  networkCode: {
    type: String,
    required: true
  },
  description: String,
  features: [String],
  category: {
    type: String,
    enum: ['daily', 'weekly', 'monthly', 'quarterly', 'yearly', 'social', 'night', 'weekend', 'student', 'business'],
    default: 'monthly'
  },
  dataAllowance: {
    type: Number, // in MB
    required: true
  },
  speed: {
    type: String,
    enum: ['2G', '3G', '4G', '5G'],
    default: '4G'
  },
  rollover: {
    type: Boolean,
    default: false
  },
  shareable: {
    type: Boolean,
    default: false
  },
  autoRenewal: {
    type: Boolean,
    default: false
  },
  validityPeriod: {
    type: Number, // in days
    required: true
  },
  tags: [String],
  metadata: {
    apiProvider: String,
    providerPlanId: String,
    lastUpdated: Date
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Indexes for performance
dataPlanSchema.index({ provider: 1, isActive: 1 });
dataPlanSchema.index({ price: 1 });
dataPlanSchema.index({ category: 1 });
dataPlanSchema.index({ planCode: 1 });

module.exports = mongoose.model('DataPlan', dataPlanSchema);